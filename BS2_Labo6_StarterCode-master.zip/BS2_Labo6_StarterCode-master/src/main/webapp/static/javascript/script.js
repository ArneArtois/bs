document.addEventListener("DOMContentLoaded", function (event) {
    // This function will get executed after the page is loaded and all scripts are loaded

    console.log('ready!');
    // Jquery can also be used
});


